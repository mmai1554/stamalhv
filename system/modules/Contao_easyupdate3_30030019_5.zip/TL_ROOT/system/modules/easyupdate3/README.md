EasyUpdate3
===========

Fork vom Contao Modul easyupdate.    
Ich habe das Modul für Contao 3 angepasst, um weiter damit arbeiten zu können.

## Installation über ER2

* [zum Contao ER2](https://contao.org/de/extension-list/view/easyupdate3.de.html)

## Installation über Composer

* Paketname suchen: `contao-legacy/easyupdate3`

## Installation manuell

* Download ZIP Datei, rechts auf dieser Seite ist dazu der Link zu finden
* auf lokaler Festplatte auspacken
* auf dem Server im Verzeichnis `system/modules` ein neues Verzeichnis `easyupdate3` anlegen
* in das Verzeichnis `system/modules/easyupdate3` nun die Dateien und Verzeichnisse der ZIP übertragen, die in dem ersten Verzeichnis liegen
* auf dem Server im Upload Verzeichnis `files` ein neues Verzeichnis `easyupdate3` anlegen, darin kommen später die ZIP Dateien für die Updates.
* sollte Ihr Upload Verzeichnis `tl_files` lauten, dann darin das Verzeichnis `easyupdate3` anlegen.

Es muss also damit existieren:    
`system/modules/easyupdate3/easyupdate3.php` ,    
`system/modules/easyupdate3/config/config.php`    
usw.

## For Translators
Translations are managed using Transifex. To create a new translation or to help to maintain an existing one, please register at transifex.com.

Project Link: [https://www.transifex.com/projects/p/contao-easyupdate3/](https://www.transifex.com/projects/p/contao-easyupdate3/)

Howto: [http://docs.transifex.com/faq/#translating](http://docs.transifex.com/faq/#translating)


## Icons
This software using the Fugue Icons from http://p.yusukekamiyamane.com/icons/search/fugue/